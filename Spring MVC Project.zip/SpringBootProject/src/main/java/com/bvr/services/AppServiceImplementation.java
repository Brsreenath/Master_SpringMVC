package com.bvr.services;

import java.io.ByteArrayInputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.bvr.domain.Employee;
import com.bvr.domain.EmploymentHistory;
import com.bvr.repository.EmployeeRepository;
import com.bvr.repository.EmploymentHistoryRepository;
import com.bvr.helper.CSVHelper;

@Service
public class AppServiceImplementation implements AppServices {
	
	private EmployeeRepository apprepository;
	
	
	private EmploymentHistoryRepository appHistoryRepository;
	
	
	
	@Autowired
	public void setAppHistoryRepository(EmploymentHistoryRepository appHistoryRepository) {
		this.appHistoryRepository = appHistoryRepository;
	}

	
	public EmploymentHistoryRepository getAppHistoryRepository() {
		return appHistoryRepository;
	}

	
	@Autowired
	public void setApprepository(EmployeeRepository apprepository) {
		this.apprepository = apprepository;
	}

	@Override
	public Iterable<Employee> listDetails() {
		
		return apprepository.findAll();
	}

	@Override
	public Employee getDetailById(Integer employee_id) {
	   Employee e;
		
		Optional<Employee> optional = apprepository.findById(employee_id);
		
		e = optional.get();
		return e ;
	}
	
	@Override
	public Employee saveDetails(Employee employee) {
		return apprepository.save(employee);
	}

	@Override
	public void deleteRecord(Integer employee_id) {
		apprepository.deleteById(employee_id);
	}

		
	@Override
	public void saveImage(MultipartFile imagefile, Employee employee) throws Exception {
		
		String folder="c:\\springbootproject\\src\\main\\resources\\static\\images\\";
		byte[] bytes=imagefile.getBytes();
		Path path = Paths.get(folder+imagefile.getOriginalFilename());
		System.out.println(path);
		Files.write(path,bytes);
		employee.setProfilePict(imagefile.getOriginalFilename());
		//File uploadedFile = new File(rootDir, name);
		//file.transferTo(uploadedFile);
	}

	public boolean findPKey(Integer employee_id) {
		boolean employee_exist;
		employee_exist=apprepository.existsById(employee_id);
		return employee_exist;
	}
	
	public ByteArrayInputStream load() {
		Iterable<Employee> employees = listDetails();

	    ByteArrayInputStream in = com.bvr.helper.CSVHelper.employeesToCSV(employees);
	    return in;
	  }
	
	
	@Override
	public List<EmploymentHistory> getEmploymentDetailById(Integer employee_id) {
		EmploymentHistory e;
		
		List<EmploymentHistory> optional= appHistoryRepository.findByEmpId(employee_id);
		
		return optional ;
	}
	
	
	public void deleteEmployee(int emp_id) {
		apprepository.deleteById(emp_id);
		//appHistoryRepository.deleteById(emp_id);
    }
	
	@Override
	public Employee getEmployeeById(Integer id) {
		Optional<Employee> optional = apprepository.findById(id);
		Employee employee = null;
		if (optional.isPresent()) {
			employee = optional.get();
		} else {
			throw new RuntimeException(" Employee not found for id :: " + id);
		}
		return employee;
	}
}

