package com.bvr.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.bvr.domain.Employee;
import com.bvr.repository.EmployeeRepository;
import com.bvr.services.AppServices;

@Controller
public class UpdateController {


	@Autowired
	private EmployeeRepository repository;
	
	@Autowired
	private AppServices appservice;
	
	
	 @PostMapping("/saveEmployee")
		public String saveEmployee(@ModelAttribute("employee") Employee employee) {
			// save employee to database
	    	appservice.saveDetails(employee);
			return "redirect:/employeeSearch";
		}
		
	    
	    @GetMapping("/showFormForUpdate/{id}")
		public String showFormForUpdate(@PathVariable ( value = "id") Integer id, Model model) {
			
			// get employee from the service
			Employee employee = appservice.getEmployeeById(id);
			
			// set employee as a model attribute to pre-populate the form
			model.addAttribute("employee", employee);
			return "UpdateEmployeeRecord";
		}
}
