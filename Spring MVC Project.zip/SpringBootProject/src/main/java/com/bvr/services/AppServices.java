package com.bvr.services;

import java.io.ByteArrayInputStream;
import java.util.List;
import java.util.Optional;

import org.springframework.web.multipart.MultipartFile;

import com.bvr.domain.Employee;
import com.bvr.domain.EmploymentHistory;


public interface AppServices {
	
	Iterable <Employee> listDetails();
	
	Employee getDetailById(Integer employee_id);
	
	Employee saveDetails(Employee employee);
	
	void deleteRecord(Integer id);

	void saveImage(MultipartFile imagefile, Employee employee) throws Exception;
	
    boolean findPKey(Integer employee_id);
    
    public ByteArrayInputStream load();
    
    public List<EmploymentHistory> getEmploymentDetailById(Integer employee_id);
    
    public void deleteEmployee(int emp_id);
    
    public Employee getEmployeeById(Integer id);
	
	

	

	

}
