package com.bvr.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.bvr.domain.EmploymentHistory;
import com.bvr.repository.EmploymentHistoryRepository;
import com.bvr.services.AppServices;
import java.util.ArrayList;

@Controller
public class HistorySearchContoller {

	
	@Autowired
	private EmploymentHistoryRepository repository;
	
	@Autowired
	private AppServices appservice;

	
	@GetMapping("/employeeHistorySearch")
	public String employeeHistorySearch(Map<String, Object> model)
	{
		List<EmploymentHistory> employments= (ArrayList<EmploymentHistory>)repository.findAll();
		model.put("employments", employments);
		return "EmployeeHistoryScreen";
	}
	
	
	@RequestMapping("/employeeHistorySearch/search_id")
	public String employee_byID(Model model,@RequestParam("emp_id") Integer emp_id ) {
		model.addAttribute("employments", appservice.getEmploymentDetailById(emp_id));
//		if(appservice.findPKey(emp_id))
//			return "EmployeeHistoryScreen";
//		else
//			return "error";
		
		return "EmployeeHistoryScreen";
	}
}
